from .data import *
from .figures import *

from .sgd_separator import plot_sgd_separator
from .linear_regression import plot_linear_regression
from .helpers import plot_iris_knn
